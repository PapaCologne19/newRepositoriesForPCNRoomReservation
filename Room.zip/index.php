<?php
header("location: Room/index.php");
?>
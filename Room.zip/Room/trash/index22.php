<html xmlns:fb="https://www.facebook.com/2008/fbml">
  <body>
    <script src="http://connect.facebook.net/en_US/all.js"></script>
    <div id="fb-root"></div>
    <script>
      // assume we are already logged in
      FB.init({appId: '100000406275230', xfbml: true, cookie: true});

      FB.ui({
          method: 'send',
          name: 'People Argue Just to Win',
          link: 'http://huu.pcnpromopro.com/index.php',
          });
     </script>
  </body>
</html>